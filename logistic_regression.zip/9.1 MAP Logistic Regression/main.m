
addpath(genpath('.'));

% Example 1
fit_logr_ex1

% Example 2
fit_logr_ex2

% Example 3
fit_logr_ex3


